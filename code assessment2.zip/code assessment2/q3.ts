var t1, array_length, counter=0;
    var name_array = ["Amar", "Raja", "Rani"];
    var place_array = ["Chennai", "Delhi", "Bangalore"];
    array_length = name_array.length;
    t1 = '<table border="1px solid black" cellspacing="0" cellpadding="5">';
    t1 += "<tr><th>Name</th><th>Score</th></tr>"
    for(counter = 0; counter < array_length; counter++) {
    t1 += "<tr><td>" + name_array[counter] + "</td><td>" + place_array[counter] + "</td></tr>";
    }
    t1 += "</table>";    
    document.getElementById("demo").innerHTML = t1;